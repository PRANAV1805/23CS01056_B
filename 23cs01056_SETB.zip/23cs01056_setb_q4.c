#include<stdio.h>
#include<math.h>
int composite(int num)
{
    int x, val1, val2,count=0;
    val1=sqrt(x);
    for(int i=1;i<val1;i++)
    {
        
    if(val2%i==0){
      count++;
    }
    
    }
    if(count>1)
    return 1;
    else
    return 0;
    

} 
int main()
{
    int i,num;
    printf("enter number");
    scanf("%d",&num);
    int counter=0;
    for(i=1;i<num/2;i++)
    {
        if(composite(i)&&composite(num-i))
        {
            counter++;
            printf("%d %d",i,num-i);
        }
    }
    if(counter==0){
        printf("no composite pair exist");
    }

    
}